import math 
math.pi
def area(radio):
    radio * math.pi**2
area(area(5))