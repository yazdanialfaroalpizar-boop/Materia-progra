import tkinter as tk
from tkinter import ttk, messagebox

# Tasas de cambio fijas (puedes actualizarlas fácilmente)
TASAS_CAMBIO = {
    ('USD', 'CRC'): 540,
    ('CRC', 'USD'): 1 / 540,
    ('USD', 'EUR'): 0.93,
    ('EUR', 'USD'): 1 / 0.93,
    ('CRC', 'EUR'): 0.93 / 540,
    ('EUR', 'CRC'): 540 / 0.93
}

def convertir():
    try:
        monto = float(entrada_monto.get())
        origen = combo_origen.get()
        destino = combo_destino.get()

        if origen == destino:
            resultado.set(f"{monto:.2f} {origen} (sin conversión)")
            return

        clave = (origen, destino)
        if clave in TASAS_CAMBIO:
            tasa = TASAS_CAMBIO[clave]
            monto_convertido = monto * tasa
            resultado.set(f"{monto_convertido:.2f} {destino}")
        else:
            messagebox.showerror("Error", "Conversión no disponible.")
    except ValueError:
        messagebox.showerror("Error", "Por favor, ingresa un número válido.")

# Crear ventana principal
ventana = tk.Tk()
ventana.title("Conversor de Monedas")
ventana.geometry("400x250")
ventana.resizable(False, False)

# Etiquetas y campos
tk.Label(ventana, text="Monto a convertir:").pack(pady=5)
entrada_monto = tk.Entry(ventana, justify="center")
entrada_monto.pack()

tk.Label(ventana, text="Moneda de origen:").pack(pady=5)
combo_origen = ttk.Combobox(ventana, values=["USD", "CRC", "EUR"], state="readonly")
combo_origen.current(0)
combo_origen.pack()

tk.Label(ventana, text="Moneda de destino:").pack(pady=5)
combo_destino = ttk.Combobox(ventana, values=["USD", "CRC", "EUR"], state="readonly")
combo_destino.current(1)
combo_destino.pack()

# Botón de conversión
tk.Button(ventana, text="Convertir", command=convertir).pack(pady=10)

# Resultado
resultado = tk.StringVar()
tk.Label(ventana, textvariable=resultado, font=("Arial", 14), fg="blue").pack(pady=10)

# Iniciar ventana
ventana.mainloop()
