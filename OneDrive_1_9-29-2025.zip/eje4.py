es_dia_soleado= True

if es_dia_soleado == True:

    print("hoy es un dia pertecto para salir")

else:

    print("es mejor quedarse en la casa")