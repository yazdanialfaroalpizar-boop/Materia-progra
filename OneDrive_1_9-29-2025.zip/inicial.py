from tkinter import *
root = Tk()

cuadro = Frame()
cuadro1 = Frame()
cuadro2 = Frame()
cuadro3 = Frame()
cuadro4 = Frame()
cuadro5 = Frame()
cuadro6 = Frame()

cuadro.config(width=50, height=50, bg="red")
cuadro.grid(row=0, column=0)

cuadro1.config(width=50, height=50, bg="red")
cuadro1.grid(row=2, column=1)

cuadro2.config(width=50, height=50, bg="red")
cuadro2.grid(row=3, column=1)

cuadro3.config(width=50, height=50, bg="red")
cuadro3.grid(row=0, column=3)

cuadro4.config(width=50, height=50, bg="red")
cuadro4.grid(row=1, column=3)

cuadro5.config(width=50, height=50, bg="red")
cuadro5.grid(row=1, column=0)

cuadro6.config(width=50, height=50, bg="red")
cuadro6.grid(row=1, column=1)



root.mainloop()