edad_str= input("porfavor ingresa tu edad")
altura_str= input("porfavor, ingrese su altura en metros")

edad_int= int(edad_str)
altura_float= float(altura_str)
print("su edad es:", edad_str, "y su tipo es", type(edad_int))
print("su altura es", altura_str, "y su tipo es", type(altura_float))
