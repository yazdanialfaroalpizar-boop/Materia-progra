año = int(input ("ingrese el año actual"))
edad = int(input("ingrese su edad"))
print("su edad actual es:", año - edad )