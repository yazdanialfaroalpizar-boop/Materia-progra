#def nombre_de_la_funcion(parametro1, parametro2):
#codigo la funcion 
def saludar(nombre):
mensaje = f"hola , {nombre}"
print(mensaje)

saludar("Juan")


