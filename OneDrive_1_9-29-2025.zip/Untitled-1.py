num1 = int(input("Ingresa el primer número: "))
num2 = int(input("Ingresa el segundo número: "))

sum = num1+num2

print("la suma de los numeros es", sum)