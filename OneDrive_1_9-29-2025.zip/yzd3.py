base = float(input("Introduce la base del triángulo: "))
altura = float(input("Introduce la altura del triángulo: "))

area = (base * altura) / 2

print(f"El área del triángulo es {area}")
