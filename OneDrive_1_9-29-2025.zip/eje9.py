dias_semana = ("Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo")
print("Primer día:", dias_semana[0])
print("Último día:", dias_semana[-1])
# Intento de modificar un elemento (esto causará un TypeError)
# dias_semana[0] = "Nuevo Lunes"
# print(dias_semana) # Si descomentas la línea anterior, verás el error