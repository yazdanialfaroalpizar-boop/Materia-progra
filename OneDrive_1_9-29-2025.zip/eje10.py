numeros_con_duplicados = [1, 2, 2, 3, 4, 4, 5, 1, 6]
print("Lista con duplicados:", numeros_con_duplicados)
conjunto_sin_duplicados = set(numeros_con_duplicados)
print("Conjunto sin duplicados:", conjunto_sin_duplicados)
lista_sin_duplicados = list(conjunto_sin_duplicados)
print("Lista resultante sin duplicados:", lista_sin_duplicados)