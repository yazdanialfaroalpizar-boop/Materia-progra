
informacion_libro = {
"titulo": "Cien años de soledad",
"autor": "Gabriel García Márquez",
"año_publicacion": 1967
}
print("Autor del libro:", informacion_libro["autor"])