def sumar(a,b)
    print(a+b)
    
    sumar(5,3)

    num1= int(imput("introduce el primer numero: "))
    num2= int(input("introduce el segundo numero: "))
    sumar(num1,num2)