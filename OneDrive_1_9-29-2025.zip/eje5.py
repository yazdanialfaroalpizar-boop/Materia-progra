lista_de_compras=["leche","papas","galletas","jabon","manzanas"]
("lista de compras:",lista_de_compras)
print("tecer elemento:",lista_de_compras[2])
