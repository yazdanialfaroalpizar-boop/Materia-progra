def bienvenido(nombre,idioma = "español"):
    if idioma == "español":
print(f"hola",{nombre})
    elif idioma == "ingles":
    print(f"hello,{nombre}") 
 else:
        print("idioma no soportado")   

    bienvenido("carlos")
bienvenido("pedro", idioma= "ingles")
bienvenido("pedro", idioma= "español")
