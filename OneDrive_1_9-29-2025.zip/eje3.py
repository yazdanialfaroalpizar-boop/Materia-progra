texto1 = "hola jefferson."
texto2 = "adios jefferson"
frascom= texto1 + texto2
print(frascom)