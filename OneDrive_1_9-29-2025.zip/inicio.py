print("Hola mundo")
num = 5 #
num2 = 5.0

nombre = input("escribe tu nombre:")
print("hola "+ nombre)