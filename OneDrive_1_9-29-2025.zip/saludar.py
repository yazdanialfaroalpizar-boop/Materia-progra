def saludar_nombre(nombre):
    print(f"¡hola,(nombre)!")


nombre = imput("introduce tu nombre: ")
b= "yazdani"
saludar_nombre(nombre)
saludar_nombre(b)
saludar_nombre("Ana")