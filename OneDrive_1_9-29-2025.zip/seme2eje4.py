def saludar(nombre):
prin(f"hola,{nombre}")

saludar("yazdani")