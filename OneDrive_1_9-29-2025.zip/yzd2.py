a = input("ingrese un numero de metros")
print("el numero de metros a centimetros es ")

metros = float(input("Introduce los metros: "))
print(metros * 100)