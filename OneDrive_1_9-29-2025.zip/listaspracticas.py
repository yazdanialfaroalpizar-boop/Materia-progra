# Imprime la lisa completa frutas
lista1 =["manzana", "banana", "cereza", "dátil"]

print(lista1)
print(lista1[0])
print(lista1[-1])
print(lista1[2])

# modifica la lista 
listacolores= ["rojo", "verde", "azul"]
listacolores[1]="amarillo"
print(listacolores)
listacolores[-1]
print(listacolores)
listacolores[1]= "naranja"
print(listacolores)

# Métodos Basicas de Listas
numeros=[10,5,20,15,25]
numeros.append (30)
print(numeros)
numeros.remove(5)
print(numeros)
ultimo = numeros.pop(-1)
print(numeros)
numeros.sort()
print(numeros)

# Longitud de una Lista y Verificación de Elementos

ciudades = ["guanacaste,San Jose,alajuela, cartago"]
print(len(ciudades))
esta= "tokio" in ciudades

#listas con Diferentes Tipos de Datos 
mixta = (12,3.14, "hola mundo", true, none )
for elemento in mixta:
    print(type(elemento))
print(mixta)