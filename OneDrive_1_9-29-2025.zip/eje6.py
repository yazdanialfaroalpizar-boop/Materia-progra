lista_de_compras=["leche","papas","galletas","jabon","manzanas"]
lista_de_compras[1]="cereales"# cambia "pan" por "papas"
lista_de_compras.append("yogurt")#añade 'yogurt' al final 
print("Lista modificada:", lista_de_compras)