nombre_completo= "Yazdani Alfaro Alpizar"
edad= 16
saldo_cuenta= 1500.90
print("nombre_completo:",nombre_completo)
print("edad:", edad)
print("saldo de la cuenta:", saldo_cuenta)