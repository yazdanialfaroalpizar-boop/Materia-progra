a=1
b=2 

c = b
b = a
a = c
print("el valor de a es" + str(a))
print("el valor de b es" + str(b))