num1 = 14
num2 = 19
suma = num1 + num2 
print("la suma es:",suma)