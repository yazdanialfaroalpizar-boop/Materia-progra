print(dir(__builtins__))
help(print)

print("h o l a", sep= "*")